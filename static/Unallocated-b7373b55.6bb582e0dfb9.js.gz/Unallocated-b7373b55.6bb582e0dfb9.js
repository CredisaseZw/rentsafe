import{j as t}from"./media/main-52a9d1f2.js";import"es-errors/type";import"es-errors/uri";function e(){return t.jsx("div",{children:"Unallocated"})}export{e as default};
