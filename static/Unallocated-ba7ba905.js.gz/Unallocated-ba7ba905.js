import{j as t}from"./media/main-e93a7206.js";import"es-errors/type";import"es-errors/uri";function e(){return t.jsx("div",{children:"Unallocated"})}export{e as default};
